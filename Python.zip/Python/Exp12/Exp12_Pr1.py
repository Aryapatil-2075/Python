sourcefile=input("Enter a Source File :")
targetfile=input("Enter a Target File :")

fileHandle=open(sourcefile,"r")
text=fileHandle.readlines()
fileHandle.close()

fileHandle=open(targetfile,"w")
for s in text:
    fileHandle.write(s)
fileHandle.close()