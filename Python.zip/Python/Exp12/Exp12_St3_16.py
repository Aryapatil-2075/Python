import calendar
Year=int(input("Enter a Year :"))
Month=int(input("Enter a Month :"))
print("Calender :",calendar.month(Year,Month))
