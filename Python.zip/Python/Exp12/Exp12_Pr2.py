import random
print(random.randint(0,5))
print(random.random())
print(random.random()*100)
List=[1,4,True,800,"Python",27,"hello"]
print(random.choice(List))