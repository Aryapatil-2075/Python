import math
r=int(input("Enter Radius :"))
areaofcircle=math.pi*r*r
print("Area of Circle :",areaofcircle)
circumferenceofcircle=2*math.pi*r
print("Circumference of Circle :",circumferenceofcircle)
