from Exp12_St1_Module import collage
collage()
