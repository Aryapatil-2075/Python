def collage():
    str=input("Enter Collage Name :")
    print(str)