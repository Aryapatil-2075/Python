class employee:
    name=""
    dept=""
    salary=""
    def getdata(self):
        self.name=str(input("Enter the Name:"))
        self.dept=str(input("Enter Department Name:"))
        self.salary=float(input("Enter the Salary:"))
class info(employee):
    def display(self):
        print("Name :",self.name)
        print("Dept :",self.dept)
        print("Salary :",self.salary)
x=info()
x.getdata()
x.display()
