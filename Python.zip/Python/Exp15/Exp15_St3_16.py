class addition():
    def add(self,no1,no2):
        self.total=no1+no2
        print("Total=",self.total)
class subtraction():
    def sub(self,no1,no2):
        self.total = no1 - no2
        print("Total=", self.total)
class arithmetic(addition,subtraction):
    def result(self):
        print("Addition is",self.add())
        print("Subtraction is",self.sub())
no1=int(input("Enter number one:"))
no2=int(input("Enter number Two:"))
x=arithmetic()
x.add(no1,no2)
x.sub(no1,no2)
