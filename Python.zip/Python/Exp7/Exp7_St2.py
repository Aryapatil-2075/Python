tp=(100,23,203,23,40,100)
rtp=[]
for i in tp:
    if(tp.count(i)>=2 and (i not in rtp)):
        rtp.append(i)
print(rtp)
#another Solution
cnt=0
while(cnt<len(tp)):
    ind=cnt+1
    while(ind<len(tp)):
        if(tp[cnt]==tp[ind]):
            print("Repeated Element",tp[ind])
        ind+=1
    cnt+=1
