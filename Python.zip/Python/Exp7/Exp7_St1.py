tp=(23,34,76,80,84)
largest=tp[0]
smallest=tp[0]
for i in tp:
    if(largest<i):
        largest=i
    if(smallest>i):
        smallest=i
print("Largest number in List  :- ",largest)
print("Smallest number in List  :- ",smallest)
#by using method
print("Max by Method max()",max(tp))
print("Min by method min()",min(tp))