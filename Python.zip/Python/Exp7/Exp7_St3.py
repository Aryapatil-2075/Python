tp=("Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine")
no=int(input("Enter Your Number:- "))
temp=no
li=[]
while(no>0):    #no=2
    d=int(no % 10)  #d=2
    li.append(tp[d]) #li=["Zero","Four","two"]
    no=no // 10   #no=2
li.reverse()  #li=["Two","Four","Zero"]
print(temp,"=>",end="")
for i in li:
    print (i,end=" ")
