class student:
    name=""
    dept=""
    marks=""
    year=""
    def getdata(self):
        self.name=str(input("Enter the Name:"))
        self.dept=str(input("Enter Department Name:"))
        self.marks=float(input("Enter the Marks:"))
        self.year=str(input("Enter the Study Year :"))
class info(student):
    def display(self):
        print("Name :",self.name)
        print("Dept :",self.dept)
        print("Marks:",self.marks)
        print("Studying Year :",self.year)
x=info()
x.getdata()
x.display()