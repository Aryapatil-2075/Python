from Exp13_St2 import Exp13_St2_Concat as ob
a=input("Enter string one :")
b=input("Enter String two :")
print(ob.samp_concat(a,b))