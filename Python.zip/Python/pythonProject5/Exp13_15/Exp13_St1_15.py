import numpy as np
x=([[1,2,5],
   [6,7,8],
    [9,3,4]])
y=([[5,2,5],
   [6,7,4],
    [9,3,4]])
print("Addition :\n",np.add(x,y))
print("Subtraction :\n",np.subtract(x,y))
print("Multiplication :\n ",np.multiply(x,y))
print("Division :\n",np.divide(x,y))
