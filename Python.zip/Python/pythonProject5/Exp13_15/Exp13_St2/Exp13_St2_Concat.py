def samp_concat(a,b):
    return a+b
