class calulate:
    def area(self,l,b):
        rectangle=l*b
        print("Area of Rectangle :",rectangle)
    def area(self,side):
        square=side*side
        print("Area of Square :",square)
obj=calulate()
obj.area(2)
obj.area(2,4)