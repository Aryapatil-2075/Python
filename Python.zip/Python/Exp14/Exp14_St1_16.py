class intchar:
    def display(self,b,a):
        print("Inside (Char,Int) Display :",b,a)

    def display(self, b, a):
        print("Inside (Int,Char) Display :",a,b)
obj=intchar()
obj.display(2,'A')
obj.display('A',2)
