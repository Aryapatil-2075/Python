class Degree:
    def getdegree(self):
        print("I got a degree !!")
class Undergraduate(Degree):
    def getdegree(self):
        print("I Got Undergraduate !!")
class Postgraduate(Degree):
    def getdegree(self):
        print("I Got Postgraduate !!")
a=Degree()
a.getdegree()
b=Undergraduate()
b.getdegree()
c=Postgraduate()
c.getdegree()
