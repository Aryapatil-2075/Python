li=[10,23,24,30,90]
s=1
for i in li:
    s=s*i
print("Multipication of Elements :- ",s)