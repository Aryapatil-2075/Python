li=[10,23,203,30,40]
largest=li[0]
for i in li:
    if(largest<i):
        largest=i
print("Largest number in List  :- ",largest)
#by using method
print(max(li))