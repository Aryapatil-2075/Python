li=[100,23,203,30,40]
rli=[40]
cnt=0
ind=-1
while(cnt<len(li)):
    rli.insert(cnt,li[ind])
    ind=ind-1
    cnt=cnt+1
print("Reverse of (li) List  :- ",rli)
#by using Operator
trli=li[::-1]
print(trli)
#by using Method (Modify Original List)
li.reverse()
print(li)