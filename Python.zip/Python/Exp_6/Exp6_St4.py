li=[100,23,203,30,40]
smallest=li[0]
for i in li:
    if(smallest>i):
        smallest=i
print("Smallest number in List  :- ",smallest)
#by using method
print(min(li))