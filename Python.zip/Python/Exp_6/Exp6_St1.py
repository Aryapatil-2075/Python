l=(10,45,56,78,56)
s=0
print("Element of List :",l)
for i in l:
    s=s+i
print("Sum of List Items :",s)