li=[100,23,203,30,40]
print(li)
for i in li:
    if(i % 2==0):
        print("Even Element in List :- ",i)