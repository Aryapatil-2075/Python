li=[100,23,203,30,40,23]
li2=[200,23,154,144,30,30,23]
cli=[]
for i in li:
    if(i in li2 and (i not in cli)):
        cli.append(i)
print("Common Element in List are:-",cli)
#Another Solution
cli=[]
cnt=0
ind=0
while(cnt<len(li)):
    ind=0
    while(ind<len(li2)):
        if(li[cnt]==li2[ind] and li2[ind] not in cli):
            cli.append(li2[ind])
        ind+=1
    cnt+=1
print("Common Elements (li) And (li2) are  :- ",cli)