import uuid
from datetime import datetime

class Employee:
    def __init__(self, name, position, hire_date):
        self.id = uuid.uuid4()
        self.name = name
        self.position = position
        self.hire_date = hire_date

    def _str_(self):
        return f"{self.name}, {self.position}, {self.hire_date}"

class EmployeeManagementSystem:
    def __init__(self):
        self.employees = []

    def add_employee(self, name, position, hire_date):
        employee = Employee(name, position, hire_date)
        self.employees.append(employee)
        print(f"Employee {employee.name} added successfully.")

    def get_employee(self, employee_id):
        for employee in self.employees:
            if employee.id == employee_id:
                return employee
        return None

    def remove_employee(self, employee_id):
        employee = self.get_employee(employee_id)
        if employee:
            self.employees.remove(employee)
            print(f"Employee {employee.name} removed successfully.")
        else:
            print("Employee not found.")

    def list_employees(self):
        for employee in self.employees:
            print(employee)

def main():
    ems = EmployeeManagementSystem()
    while True:
        print("\nEmployee Management System")
        print("1. Add Employee")
        print("2. Get Employee")
        print("3. Remove Employee")
        print("4. List Employees")
        print("5. Exit")
        choice = int(input("Enter your choice: "))
        if choice == 1:
            name = input("Enter employee name: ")
            position = input("Enter employee position: ")
            hire_date = input("Enter employee hire date (dd/mm/yyyy): ")
            hire_date = datetime.strptime(hire_date, "%d/%m/%Y").date()
            ems.add_employee(name, position, hire_date)
        elif choice == 2:
            employee_id = uuid.UUID(input("Enter employee id: "))
            employee = ems.get_employee(employee_id)
            if employee:
                print(employee)
            else:
                print("Employee not found.")
        elif choice == 3:
            employee_id = uuid.UUID(input("Enter employee id: "))
            ems.remove_employee(employee_id)
        elif choice == 4:
            ems.list_employees()
        elif choice == 5:
            break
        else:
            print("Invalid choice.")

em =EmployeeManagementSystem()
em.list_employees()
