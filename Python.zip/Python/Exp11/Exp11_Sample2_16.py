num = 1
def func():
    num=3
    print(num)
func()
print(num)