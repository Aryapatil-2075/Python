def myFunction(text,num):
    while num > 0:
        print(text)
        num= num - 1
myFunction('Hello',4)