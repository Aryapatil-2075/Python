def prime(n):
    if(n==1):
        return False
    elif(n==2):
        return True
    else:
        for x in range(2,n):
            if(n % x==0):
                return False
            return True
no=int(input("Enter any Number :"))
r=prime(no)
if r:
    print("Number is Prime Number !!")
else:
    print("Number is not Prime Number !!")