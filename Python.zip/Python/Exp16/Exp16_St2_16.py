password=str(input("Enter Password :"))
try:
    if(password=="Arya"):
        print("Password is Correct !!")
    else:
        raise ValueError
except ValueError:
    print("Password is Incorrect !!")
