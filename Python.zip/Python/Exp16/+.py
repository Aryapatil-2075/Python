fname="arya"
lastname="patil"
fullname=fname+""+lastname
print(fullname)
