a=int(input("Enter First Number :"))
b=int(input("Enter Second Number :"))
try:
    x=a/b
    print(x)
except ZeroDivisionError:
    print("Division by zero:- Value of B Considered as 1")
    x=a/1
    print("Value of x :",x)


