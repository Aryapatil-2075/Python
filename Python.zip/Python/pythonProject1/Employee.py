
class Employee:
    def __init__(self, emp_id, emp_name, emp_salary):
        self.emp_id = emp_id
        self.emp_name = emp_name
        self.emp_salary = emp_salary

class Emp:
    def __init__(self):
        self.employees = []

    def add_employee(self, emp_id, emp_name, emp_salary):
        employee = Employee(emp_id, emp_name, emp_salary)
        self.employees.append(employee)
        print(f"Employee {emp_name} added successfully!")

    def view_employees(self):
        if not self.employees:
            print("No employees in the system.")
        else:
            print("Employee List:")
            for employee in self.employees:
                print(f"ID: {employee.emp_id}, Name: {employee.emp_name}, Salary: {employee.emp_salary}")

    def search_employee(self, emp_id):
        for employee in self.employees:
            if employee.emp_id == emp_id:
                print(f"Employee found - ID: {employee.emp_id}, Name: {employee.emp_name}, Salary: {employee.emp_salary}")
                return
        print(f"No employee found with ID {emp_id}.")

# Example usage:
ems = Emp()
ems.add_employee(1, "John Doe", 50000)
ems.add_employee(2, "Jane Smith", 60000)
ems.view_employees()
ems.search_employee(1)

class Employee1:
    def getdata(self,empid,empname,basicsal,tax_rate):
        self.empid=empid
        self.empname=empname
        self.basicsal=basicsal
        self.tax_rate = tax_rate
    def calculate(self):
        da=(self.basicsal*90/100)
        hra=(self.basicsal*25/100)
        ta=(self.basicsal*20/100)
        pf=(self.basicsal*10/100)
        self.netsal=(self.basicsal+da+hra+ta+pf)
        tax_amount = self.basicsal * self.tax_rate
        net_salary = self.basicsal - tax_amount
        return net_salary
    def display(self):
        print("Employee ID=",self.empid,"\nEmployee Name=",self.empname,"\n Net Salary=",self.netsal)
        print(f"Tax Amount: ${e.basicsal * e.tax_rate}")

e=Employee1()
empid=int(input("Enter Employee ID"))
empname=input("Enter Employee Name")
basicsal=int(input("Enter Basic Salary"))

tax_rate = float(input("Enter tax rate (in decimal): "))
e.getdata(empid,empname,basicsal,tax_rate)
e.calculate()
e.display()
