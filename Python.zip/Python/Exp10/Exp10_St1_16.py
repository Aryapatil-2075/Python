def string(str):
    uppercase=0
    lowercase=0
    for i in str:
        if i.isupper():
            uppercase+=1
        elif i.islower():
            lowercase+=1
        else:
            pass
    print("Original String : ",str)
    print("Uppercase Letters in Original Strings are :",uppercase)
    print("Lowercase Letters in Original Strings are :",lowercase)
string("Latthe Education Society's Polytechnic, Sangli")

