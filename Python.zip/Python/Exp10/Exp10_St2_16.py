import random
print("Random Integer number between 5 to 50 :",random.randint(5,50))
print("Random Float number between 5 to 50 :",format(random.uniform(5,50),"<5.2f"))