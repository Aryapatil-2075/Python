from Exp13_St2_16 import Exp13_St2_concat as ob
a=input("First String :")
b=input("Second String :")
print("Concatination of Two Strings :",a,b)