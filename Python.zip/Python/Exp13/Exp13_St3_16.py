import numpy as np
x=np.random.randint(low=10,high=30,size=8)
print(x)