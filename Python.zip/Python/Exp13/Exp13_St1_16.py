import numpy as np
x=([1,2,5],
   [6,7,8],
   [9,2,5])
y=([4,6,5],
   [7,2,8],
   [9,1,3])
print("Addition :\n",np.add(x,y))
print("Substraction :\n",np.sub(x,y))
print("Multiplication :\n",np.mul(x,y))
print("Division :\n",np.div(x,y))