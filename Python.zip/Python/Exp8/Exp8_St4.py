#using in-build method
set={55,33,11,99,40}
print(len(set))
#using loop
cnt=0
for i in set:
    cnt=cnt+1
print("Length of set is :",cnt)

