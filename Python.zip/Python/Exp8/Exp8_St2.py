A={10,20,99,40,50};
B={60,70,80,90,99};
print("Set A :",A)
print("Set B :",B)
print("Intersection of A and B set :",A.intersection(B))
print("Union of A and B set :",A.union(B))
print("Set Difference of A and B set :",A.difference(B))
print("Symmetric Difference of A and B :",A.symmetric_difference(B))
A.clear()
print("Clearing the set :",A)