set={10,20,30,40,50}
print("Original Set :",set)
set.add(60)
print(" After Adding elements in set by add() method :",set)
set.update({70,80})
print("After Adding elements in set by update() method :",set)
set.remove(40);
print("After removing elements in set by remove() method :",set)
