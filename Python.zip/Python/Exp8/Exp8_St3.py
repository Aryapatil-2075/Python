#using in-built method
A={100,40,30,200,10};
print(max(A))
print(min(A))
#using loop
g=m=A.pop()
for x in A:
    if(m>x):
        m=x
    if(g<x):
            g=x
print("Maximum :",g)
print("Minimum :",m)
