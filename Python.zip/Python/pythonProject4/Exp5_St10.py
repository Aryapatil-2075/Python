num = int(input("Enter the number of terms in the Fibonacci series: "))
a, b = 0, 1
print("Fibonacci Series:")
print(a, b, end=' ')
for _ in range(num - 2):
    a, b = b, a + b
    print(b, end=' ')