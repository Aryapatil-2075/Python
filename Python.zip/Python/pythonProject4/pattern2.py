x=2
j=1
for i in range(1,4):
    print(" "*x,"*"*j)
    j=j+2
    x=x-1
j=3
x=1
for i in range(1,3):
    print(" "* x,"*"*j)
    j=j-2
    x=x+1