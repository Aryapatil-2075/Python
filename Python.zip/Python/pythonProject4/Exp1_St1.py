

sub1=int(input("Enter Marks of subject OOP out of 100:"))
sub2=int(input("Enter Marks of Subject AJP out of 100:"))
sub3=int(input("Enter Marks of Subject STE out of 100:"))
sub4=int(input("Enter Marks of Subject OSY out of 100:"))
sub5=int(input("Enter Marks of Subject EST out of 100:"))
avg=(sub1+sub2+sub3+sub4+sub5)/5
print("Average=",avg)
if(avg>75):
    print("First Class Distinction")
elif(avg < 75 and avg >60):
    print("First Class")
elif(avg<60 and avg>40):
    print("Pass Class")
else:
    print("fail")











