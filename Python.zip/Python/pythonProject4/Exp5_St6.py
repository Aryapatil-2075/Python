sum=0
for i in range(0,10):
    sum=sum+i
print(sum,end=" ")