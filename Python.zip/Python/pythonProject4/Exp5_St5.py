i=2
print("Even Number from 1 to 100 !")
while i<=100:
    print(i,end=" ")
    i+=2