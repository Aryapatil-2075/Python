m=0
for i in range(8,1,-2):
    print(" "* m,end="")
    for j in range(i,1,-1):
        if j % 2 ==0:
            print("1",end="")
        else:
            print("0",end="")
    print("\r")
    m+=1