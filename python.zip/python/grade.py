rollno=int(input("Enter Roll_no"))
name=input("Enter Name")
M1=int(input("Enter Marks of M1"))
M2=int(input("Enter Marks of M2"))
M3=int(input("Enter Marks of M3"))
Total=M1+M2+M3
per=Total/3
if(per>=75):
    print("Distinction")
elif(per>=60):
    print("First Class")
elif(per>=50):
    print("Second Class")
elif(per>=40):
    print("Pass")
else:
    print("Fail")
print("Roll_no:",rollno)
print("Name:",name)
print("M1:",M1)
print("M2:",M2)
print("M3:",M3)
print("Total:",Total)
print("Percentage:",per)
