n=int(input("Enter number"))
i=1
while(i<=10):
    print(n,"*",i,"=",n*i)
    i=i+1
