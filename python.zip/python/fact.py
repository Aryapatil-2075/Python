n=int(input("Enter Number"))
fact=1
i=n
while(i>=1):
    fact=fact*i
    i=i-1
print("Factorial:",fact)
