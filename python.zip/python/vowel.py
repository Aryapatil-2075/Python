ch=input("Enter Character")
if(ch=='A' or ch=='a' or ch=='E' or ch=='e'or ch=='I' or ch=='i' or ch=='O' or ch=='o'or
   ch=='U' or ch=='u'):
    print("Character is Vowel")
else:
    print("Character is Consonant")
