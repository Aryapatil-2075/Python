print("Armstrong no")
n=1
while(n<=1000):
     sum=0
     n1=n
while(n>0):
    d=(n%10)
    sum=sum+(d*d*d)
    n=int(n/10)
if(n1==sum):
    print(n1)
n=n1
n=n+1
