for i in range(69,0,-1):
    for j in range(65,i+1):
        print(chr(j),end='')
    print()
