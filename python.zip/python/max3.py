a=int(input("Enter a"))
b=int(input("Enter b"))
c=int(input("Enter c"))
if(a>b):
    if(a>c):
        print("A is Maximum",a)
    else:
        print("C is Maximum",c)
else:
    if(b>c):
        print("b is Maximum",b)
    else:
        print("c is Maximum",c)
