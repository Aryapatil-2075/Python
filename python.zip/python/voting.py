age=int(input("Enter Age"))
if(age>18):
    print("Is Eligible for Voting",age)
else:
    print("Is Not Eligible for Voting",age)
