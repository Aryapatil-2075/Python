n=int(input("Enter Number"))
sum=0
n1=n
while(n>0):
    digit=n%10
    sum=sum+(digit*digit*digit)
    n=int(n/10)
if(n1==sum):
    print("Number is Armstrong",n1)
else:
     print("Number is Not Armstrong",n1)
