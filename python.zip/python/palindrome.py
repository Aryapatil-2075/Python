n=int(input("Enter Number"))
rev=0
n1=n
while(n>0):
    digit=n%10
    rev=rev*10+digit
    n=int(n/10)
if(n1==rev):
    print("Number is Palindrome",n1)
else:
     print("Number is Not Palindrome",n1)

