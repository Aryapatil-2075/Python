a=int(input("Enter a"))
b=int(input("Enter b"))
if(a>b):
    print("A is maximum",a)
else:
    print("B is maximum",b)
