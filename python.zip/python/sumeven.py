sum=0
i=2
while(i<=10):
    sum=sum+i
    i+=2
print("Sum:",sum)
