n=int(input("Enter number"))
if(n%2==0):
    print("No is even number",n)
else:
    print("No is Odd Number",n)
