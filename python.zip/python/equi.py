a=int(input("Enter a"))
b=int(input("Enter b"))
c=int(input("Enter c"))
if(a==b and b==c):
    print("Triangle is Equilateral")
else:
    print("Triangle is Not Equilateral")
